# compilation and run

python3 main.py
